class UserTypeSelected {
  var farmer = 'Farmer';
  var buyer = 'Buyer';
  var transporter = 'Trasporter';

  String FarmerSelected() {
    return farmer;
  }

  String BuyerSelected() {
    return buyer;
  }

  String TransporterSelected() {
    return transporter;
  }
}
